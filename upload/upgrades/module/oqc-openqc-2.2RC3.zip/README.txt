Open Quotes and Contracts
=========================

In order to create a PDF document of an offering or contract you have to
install the following software:

 - pdftk
 - pdflatex

In order to convert MS doc files to pdf files You need following software:
 - Python
 - OpenOffice.org with headless support and the Python UNO bridge
 - DocumentConverter.py (also named PyODConverter)

OpenOffice.org is run as a service listening by default on Port 8100. So also confirm that this port is still free.

Many thanks to our contributors:
German translation by Berndt Dongus.
Spanish translation by Eduardo Hernandez.
French translation by Aurelien Mauricard, Osytos Inc.
Portugese/Brasil translation by Jader Simoes. 

<?php
require_once('include/MVC/Controller/SugarController.php');
require_once('modules/oqc_Service/oqc_Service.php');
require_once('modules/oqc_TextBlock/oqc_TextBlock.php');
require_once('modules/oqc_EditedTextBlock/oqc_EditedTextBlock.php');
require_once('modules/Documents/Document.php');
require_once('modules/oqc_Contract/oqc_ContractBaseController.php');

class oqc_ContractController extends oqc_ContractBaseController
{
}

?>

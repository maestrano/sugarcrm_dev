<?php
$dashletMeta['AllContractsDashlet'] = array(
	'title'       => translate('LBL_ALLCONTRACTS', 'oqc_Contract'),
	'description' => translate('LBL_ALLCONTRACTS', 'oqc_Contract'), 
 	'icon'        => 'themes/default/images/icon_DetailView.gif',
	'category'    => 'Tools'
);
?>

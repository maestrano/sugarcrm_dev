<?php
$module_name = 'oqc_Category';
$listViewDefs = array (
$module_name =>
array (
  'NUMBER' => 
  array (
    'width' => '10',
    'label' => 'LBL_NUMBER',
    'default' => true,
    'link' => true,
  ),
  'NAME' => 
  array (
    'width' => '30',
    'label' => 'LBL_NAME',
    'default' => true,
    'link' => true,
  ),  
  'CATALOG_NAME' => 
  array (
    'width' => '30',
    'label' => 'LBL_CATALOG_NAME',
    'default' => true,
    'link' => true,
  ),
  'DESCRIPTION' => 
  array (
    'width' => '30',
    'label' => 'LBL_DESCRIPTION',
    'sortable' => false,
    'default' => true,
  ),

)
);
?>

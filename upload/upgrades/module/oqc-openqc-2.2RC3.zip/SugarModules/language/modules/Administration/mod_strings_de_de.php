<?php

$mod_strings = array_merge($mod_strings,
	array(
		 'LBL_OQC_TITLE' => "Konfiguration anpassen",
		 'LBL_OQC_SETTINGS' => "OQC Kofigurationseditor",
		 'LBL_OQC_HEADER' => "Open Quotes And Contracts",
		 'LBL_OQC_DESCRIPTION' => "Konfigurationsdatei anpassen",
		 'LBL_OQC_TASK_CONFIG_HINT' => 'Standardbenutzer für TeamAufgaben einstellen',
		 'LBL_OQC_CONFIG_USERS_TITLE' => 'Standardbenutzer für TeamAufgaben anpassen',
		  'LBL_OQC_CLEAN_UP_TITLE'=> 'Clean up database',
		 'LBL_OQC_CLEAN_UP_HINT' => 'Delete old versions of Products, Quotes or Contracts from database',
	)
);
?>

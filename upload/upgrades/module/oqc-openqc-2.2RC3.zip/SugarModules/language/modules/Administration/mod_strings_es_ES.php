<?php

$mod_strings = array_merge($mod_strings,
	array(
		 'LBL_OQC_TITLE' => "Editar fichero configuracion",
		 'LBL_OQC_SETTINGS' => "Openqc Editor Fichero Configuracion",
		 'LBL_OQC_HEADER' => "Open Ofertas Y Contratos",
		 'LBL_OQC_DESCRIPTION' => "Editar opciones Fichero Configuracion",
		 'LBL_OQC_TASK_CONFIG_HINT' => 'Configurar Usuarios incluidos en Tareas de Equipo por defecto',
		 'LBL_OQC_CONFIG_USERS_TITLE' => 'Editar Usuarios por defecto de Tareas de Equipo',
		 'LBL_OQC_CLEAN_UP_TITLE'=> 'Limpiar Base de Datos',
		 'LBL_OQC_CLEAN_UP_HINT' => 'Borrar versiones antiguas de Productos, Ofertas o Contratos de base de datos',

	)
);
?>

<?php

$mod_strings = array_merge($mod_strings,
	array(
		 'LBL_OQC_TITLE' => "Modifier le fichier de config",
		 'LBL_OQC_SETTINGS' => "Openqc Editeur de fichier de config",
		 'LBL_OQC_HEADER' => "Open Quotes And Contracts",
		 'LBL_OQC_DESCRIPTION' => "Modifier les paramčtres du fichier de config",
		 'LBL_OQC_TASK_CONFIG_HINT' => 'Configurer les Utilisateurs qui seront ajoutés par défaut aux Projets',
		 'LBL_OQC_CONFIG_USERS_TITLE' => 'Modifier les utilisateurs par défaut des Projets',
		 'LBL_OQC_CLEAN_UP_TITLE'=> 'Nettoyer la base de données',
		 'LBL_OQC_CLEAN_UP_HINT' => 'Supprimer ou effacer des vieilles versions de Produits, Devis ou Contrats de la base de données',

	)
);
?>

<?php

$mod_strings = array_merge($mod_strings,
	array(
	 	 'LBL_OQC_TITLE' => "Edit Config file",
		 'LBL_OQC_SETTINGS' => "OQC Config File Editor",
		 'LBL_OQC_HEADER' => "Open Quotes And Contracts",
		 'LBL_OQC_DESCRIPTION' => "Edit Config File settings",
		'LBL_OQC_TASK_CONFIG_HINT' => 'Configure Users that will be included in TeamTasks by default',
		 'LBL_OQC_CONFIG_USERS_TITLE' => 'Edit TeamTasks default users',
		  'LBL_OQC_CLEAN_UP_TITLE'=> 'Clean up database',
		 'LBL_OQC_CLEAN_UP_HINT' => 'Delete old versions of Products, Quotes or Contracts from database',
	)
);
?>

<?php

$mod_strings = array_merge($mod_strings,
	array(
		 'LBL_OQC_OFFERING_SUBPANEL_TITLE' => "oqc_Propostas",
		 'LBL_OQC_CONTRACT_SUBPANEL_TITLE' => "oqc_Contratos",
		 'LBL_OQC_PRODUCT_SUBPANEL_TITLE' => "oqc_Produtos",
		 'LBL_OQC_ADDITION_SUBPANEL_TITLE' => "oqc_Aditivos",
		 'LBL_OQC_EXTERNALCONTRACT_SUBPANEL_TITLE' => "oqc_ContratosExternos",
		 'LBL_OQC_TASK_SUBPANEL_TITLE' => "oqc_Tarefa",
		 'LBL_DOCUMENT_PURPOSE' => "Document purpose",
	)
);
?>

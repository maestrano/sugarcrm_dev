<?php

$mod_strings = array_merge($mod_strings,
	array(
		 'LBL_OQC_OFFERING_SUBPANEL_TITLE' => "oqc_Devis",
		 'LBL_OQC_CONTRACT_SUBPANEL_TITLE' => "oqc_Contrats",
		 'LBL_OQC_PRODUCT_SUBPANEL_TITLE' => "oqc_Produits",
		 'LBL_OQC_ADDITION_SUBPANEL_TITLE' => "oqc_Additions",
		 'LBL_OQC_EXTERNALCONTRACT_SUBPANEL_TITLE' => "oqc_ContratsExternes",
		 'LBL_OQC_OFFICE_NUMBER' => "Office phone code",
		  'LBL_OQC_EXTERNAL' => 'Is Supplier?',
	)
);
?>

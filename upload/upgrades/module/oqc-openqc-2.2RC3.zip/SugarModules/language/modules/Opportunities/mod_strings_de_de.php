<?php

$mod_strings = array_merge($mod_strings,
	array(
		 'LBL_OQC_OFFERING_SUBPANEL_TITLE' => "oqc_Angebote",
		 'LBL_OQC_CONTRACT_SUBPANEL_TITLE' => "oqc_Verträge",
		 'LBL_OQC_PRODUCT_SUBPANEL_TITLE' => "oqc_Produkte",
		 'LBL_OQC_ADDITION_SUBPANEL_TITLE' => "oqc_Ergänzungen",
		 'LBL_OQC_EXTERNALCONTRACT_SUBPANEL_TITLE' => "oqc_ExterneVerträge",
	)
);
?>
